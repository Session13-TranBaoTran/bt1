@echo off
REM ============================================================
REM auto_report.bat - Robot loc log GreenTech
REM Loc dong CRITICAL va ERROR tu log-he-thong.log,
REM chen noi (>>) vao backup\bao-cao-su-co.txt
REM ============================================================
setlocal

REM Duong dan tuong doi tinh tu vi tri file .bat (scripts\)
set "ROOT=%~dp0.."
set "LOG=%ROOT%\data\log-he-thong.log"
set "OUT=%ROOT%\backup\bao-cao-su-co.txt"

REM --- Buoc audit: kiem tra truoc khi chay ---
REM Script nay chi DOC log va GHI NOI bao cao.
REM Khong co lenh xoa (del /f /s /q, rd /s /q). Da ra soat thu cong.
if not exist "%LOG%" (
    echo [LOI] Khong tim thay file log: %LOG%
    exit /b 1
)
if not exist "%ROOT%\backup" mkdir "%ROOT%\backup"

REM --- Tieu de bao cao ---
echo ============================================================ >> "%OUT%"
echo BAO CAO SU CO HE THONG - GREENTECH >> "%OUT%"
echo Thoi diem tao: %date% %time% >> "%OUT%"
echo Nguon: data\log-he-thong.log >> "%OUT%"
echo ============================================================ >> "%OUT%"

REM --- Loc bang Pipe: type doc tung dong, findstr loc, khong nap ca file vao RAM ---
type "%LOG%" | findstr /C:"CRITICAL" /C:"ERROR" >> "%OUT%"

echo ------------------------------------------------------------ >> "%OUT%"
echo Het bao cao. >> "%OUT%"
echo.>> "%OUT%"

echo Da ghi bao cao vao: %OUT%
endlocal
