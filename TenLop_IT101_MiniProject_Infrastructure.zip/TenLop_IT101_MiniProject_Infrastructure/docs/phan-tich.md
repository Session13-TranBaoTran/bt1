# Phân tích bài MiniProject GreenTech

## IPO và DIKW

| Bước | Nội dung trong bài |
|---|---|
| Input | File `log-he-thong.log` (hàng triệu dòng), bảng `trang-thai-tram` |
| Process | `findstr` lọc CRITICAL/ERROR, VLOOKUP kết hợp TRIM để đối soát mã linh kiện |
| Output | `bao-cao-su-co.txt`, bảng trạm có tên thiết bị đầy đủ |

| Tầng DIKW | Ví dụ |
|---|---|
| Data | Từng dòng log, mã trạm, mã linh kiện |
| Information | Các dòng lỗi đã lọc, trạm nào dùng linh kiện nào |
| Knowledge | Lỗi TIMEOUT tập trung ở loại linh kiện nào |
| Wisdom | Quyết định thay linh kiện hoặc nâng cấp mạng cho trạm hay lỗi |

## Các bẫy và cách xử lý

| Bẫy | Cách xử lý |
|---|---|
| Terminal | Tên thư mục kebab-case, không dấu, không khoảng trắng |
| Script | Có bước audit: script chỉ đọc và ghi nối, không có `del /f /s /q`; kiểm tra file log tồn tại trước khi chạy |
| Excel | Không hàng trống, không merge cell để AutoFilter hoạt động; dùng TRIM để hết #N/A |
| Hardware | 1 byte = 8 bit nên MB/s = Mbps / 8; 100 Mbps tải 500 MB mất 40 giây |

## Vì sao dùng Pipe với file 500 MB

`type file | findstr ...` truyền dữ liệu theo từng dòng qua pipe, `findstr` lọc rồi ghi ra ngay, nên không phải nạp cả 500 MB vào RAM một lần.

## Khi AI gợi ý lệnh xóa nguy hiểm

Nếu AI gợi ý thêm bước dọn dẹp bằng `del /f /s /q`, cần đọc lại: `/s` xóa đệ quy và `/q` không hỏi xác nhận, chạy sai đường dẫn có thể mất cả thư mục. Bài này bỏ hẳn bước xóa; muốn lưu trữ thì dùng `>>` để nối thêm thay vì xóa rồi tạo lại.
