# GreenTech System - Quản lý hạ tầng và xử lý log

Hệ thống hỗ trợ kỹ sư hạ tầng (DevOps) của Startup GreenTech: tổ chức dữ liệu dự án, tự động lọc log sự cố và đối soát 100 trạm cảm biến IoT.

## Cấu trúc thư mục

```text
greentech-system/
├── docs/       README.md, srs-he-thong.docx
├── scripts/    auto_report.bat
├── data/       log-he-thong.log, quan-ly-thiet-bi.xlsx
├── backup/     bao-cao-su-co.txt (sinh ra khi chạy script)
└── .env        cấu hình giả định
```

## Khởi tạo dự án (Git Bash)

```bash
mkdir -p greentech-system/{docs,scripts,data,backup}
cd greentech-system
echo "DB_PASSWORD=Demo@2026" > .env
```

## Chạy script lọc log

Từ thư mục gốc của dự án, trên Windows:

```bat
scripts\auto_report.bat
type backup\bao-cao-su-co.txt
```

Script đọc `data\log-he-thong.log`, lọc các dòng chứa `CRITICAL` hoặc `ERROR` rồi chèn nối vào `backup\bao-cao-su-co.txt`. Script không có lệnh xóa nào.

## Checklist kiểm tra thiết bị

- [ ] Tên thư mục viết kebab-case, không dấu, không khoảng trắng
- [ ] Sheet `danh-muc-linh-kien` có khóa chính `ma_linh_kien`
- [ ] Cột mã linh kiện của trạm đã qua `TRIM`
- [ ] VLOOKUP dùng tham số `FALSE` và khóa vùng tra cứu bằng `$`
- [ ] Đối chiếu số trạm thực tế ngoài trang trại
- [ ] Cập nhật `ngay_lap_dat` khi thay linh kiện

## Bảng thông số phần cứng

| ma_linh_kien | ten_thiet_bi | loai_storage | don_gia (VND) |
|---|---|---|---|
| LK001 | CPU ESP32-S3 | SSD | 85,000 |
| LK005 | RAM 1GB LPDDR4 | SSD | 150,000 |
| LK006 | SSD 32GB eMMC | SSD | 190,000 |
| LK008 | HDD 500GB 2.5 inch | HDD | 480,000 |
| LK011 | Module LoRa SX1278 | SSD | 130,000 |

Danh sách đầy đủ nằm trong `data/quan-ly-thiet-bi.xlsx`.

## Thời gian tải log

File log 500 MB, tốc độ mạng tính bằng Mbps, chia 8 để ra MB/s.

| Tốc độ mạng | MB/s | Thời gian tải 500 MB |
|---|---|---|
| 50 Mbps | 6,25 | 80 giây |
| 100 Mbps | 12,5 | 40 giây |
| 200 Mbps | 25 | 20 giây |
